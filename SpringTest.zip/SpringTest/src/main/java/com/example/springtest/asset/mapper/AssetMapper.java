package com.example.springtest.asset.mapper;

import com.example.springtest.asset.dto.Asset;
import com.example.springtest.employee.dto.Employee;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AssetMapper implements RowMapper<Asset> {



    @Override
    public Asset mapRow(ResultSet rs, int rowNum) throws SQLException {
        Asset asset =new Asset();
        asset.setAssetId(rs.getInt("asset_id"));
        asset.setOrgName(rs.getString("org_name"));
        asset.setEmpName(rs.getString("emp_name"));
        asset.setAssetName(rs.getString("asset_name"));

        return asset;
    }
}
