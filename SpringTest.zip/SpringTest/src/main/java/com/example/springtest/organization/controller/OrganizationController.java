package com.example.springtest.organization.controller;

import com.example.springtest.organization.dto.Organization;
import com.example.springtest.organization.service.OrganizationService;
import com.example.springtest.organization.vo.OrganizationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("organizations")
public class OrganizationController {

    @Autowired
    private OrganizationService organizationService;

    @GetMapping( "getAll")
    public ResponseEntity<List<Organization>>  getOrganizations() throws SQLException {
     List<Organization> list= organizationService.getAllOrganizations();
     if(list.isEmpty()){
         return new ResponseEntity<>(HttpStatus.NO_CONTENT);
     }
     return new ResponseEntity<>(list,HttpStatus.OK);
    }
    @GetMapping( "getById/{id}")
    public  ResponseEntity<Organization>  getOrganizationById(@PathVariable("id") int orgId) throws SQLException {
        Organization organization=  organizationService.getOrganizationById(orgId);
        if(organization!=null){
            return new ResponseEntity<>(organization,HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("newOrganization")
    public ResponseEntity<String> saveOrganization(@RequestBody OrganizationVO organizationVO){
        boolean result = organizationService.saveOrganization(organizationVO);
        if(result){
            return new ResponseEntity<>("Organization inserted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

    @PutMapping("updateOrganization/{id}")
    public ResponseEntity<String> updateOrganization(@PathVariable("id") int orgId, @RequestBody OrganizationVO organizationVO){
        boolean result = organizationService.updateOrganization(orgId, organizationVO);
        if(result){
            return new ResponseEntity<>("Organization updated successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }
    @DeleteMapping("deleteOrganization/{id}")
    public ResponseEntity<String> deleteOrganization(@PathVariable("id") int orgId){
        boolean result = organizationService.deleteOrganization(orgId);
        if(result){
            return new ResponseEntity<>("Organization deleted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

}
