package com.example.springtest.asset.service;

import com.example.springtest.asset.dao.AssetDAO;
import com.example.springtest.asset.dto.Asset;
import com.example.springtest.asset.vo.AssetVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetService {

    @Autowired
    private AssetDAO assetDAO;
    public List<Asset> getAllAssets() {
        return assetDAO.getAllAssets();
    }

    public Asset getAssetById(int id) {
        return assetDAO.getAssetById(id);
    }

    public boolean saveAsset(AssetVO assetVO) {
        return assetDAO.saveAsset(assetVO);
    }

    public boolean updateAsset(int id, AssetVO assetVO) {
        return assetDAO.updateAsset(id, assetVO);
    }

    public boolean deleteAsset(int id) {
        return assetDAO.deleteAsset(id);
    }
}
