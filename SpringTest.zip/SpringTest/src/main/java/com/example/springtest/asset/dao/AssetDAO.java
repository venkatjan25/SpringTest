package com.example.springtest.asset.dao;

import com.example.springtest.asset.dto.Asset;
import com.example.springtest.asset.vo.AssetVO;

import java.util.List;

public interface AssetDAO {

    List<Asset> getAllAssets();
    Asset getAssetById(int id);

    boolean saveAsset(AssetVO AssetVO);

    boolean updateAsset(int id, AssetVO AssetVO);

    boolean deleteAsset(int id);
}
