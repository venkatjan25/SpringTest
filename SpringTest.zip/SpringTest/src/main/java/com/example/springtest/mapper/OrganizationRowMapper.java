package com.example.springtest.mapper;

import com.example.springtest.organization.dto.Organization;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class OrganizationRowMapper implements RowMapper<Organization> {

    @Override
    public Organization mapRow(ResultSet rs, int rowNum) throws SQLException {
        Organization org =new Organization();
        org.setOrgId(rs.getInt("org_id"));
        org.setOrgName(rs.getString("org_name"));
        org.setOrgCity(rs.getString("org_city"));
        return org;
    }
}
