package com.example.springtest.organization.dto;

import org.springframework.stereotype.Component;

@Component
public class Organization {
    private int orgId ;
    private String orgName;
    private String orgCity;

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getOrgCity() {
        return orgCity;
    }

    public void setOrgCity(String orgCity) {
        this.orgCity = orgCity;
    }
}
