package com.example.springtest.organization.vo;

public class OrganizationVO {

    private String orgname;
    private String orgcity;


    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public String getOrgcity() {
        return orgcity;
    }

    public void setOrgcity(String orgcity) {
        this.orgcity = orgcity;
    }
}
