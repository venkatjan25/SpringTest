package com.example.springtest.asset.daoimpl;

import com.example.springtest.asset.dao.AssetDAO;
import com.example.springtest.asset.dto.Asset;
import com.example.springtest.asset.mapper.AssetMapper;
import com.example.springtest.asset.vo.AssetVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;

@Repository
public class AssetDAOImpl implements AssetDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Asset> getAllAssets() {
        String query= "select * from asset a , organization o,employee e where e.org_id=o.org_id and a.emp_id=e.emp_id ";
        try{
            return jdbcTemplate.query(query,new AssetMapper());
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return null;
    }

    @Override
    public Asset getAssetById(int id) {
        String query= "select * from asset a , organization o,employee e where e.org_id=o.org_id and a.emp_id=e.emp_id" +
                " and a.asset_id="+id;
        Asset asset = new Asset();
        try{
            SqlRowSet rowSet=  jdbcTemplate.queryForRowSet(query);
            while (rowSet.next()) {
                asset.setAssetId(rowSet.getInt("asset_id"));
                asset.setOrgName(rowSet.getString("org_name"));
                asset.setEmpName(rowSet.getString("emp_name"));
                asset.setAssetName(rowSet.getString("asset_name"));

            }
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return asset;
    }

    @Override
    public boolean saveAsset(AssetVO assetVO) {
        String query="insert into asset (emp_id,asset_name) values(?,?)";
        try{
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(query, new String[] { "asset_id" });
                ps.setInt(1, assetVO.getEmpId());
                ps.setString(2, assetVO.getAssetName());
                return ps;
            }, keyHolder);
            return keyHolder.getKey().longValue()>0;

        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateAsset(int id, AssetVO assetVO) {

        String query="update asset set emp_id=empId,asset_name='assetName' where asset_id="+id;
        try{
            query= query.replaceAll("empId",String.valueOf(assetVO.getEmpId()));
            query=query.replaceAll("assetName",assetVO.getAssetName());

            int count= jdbcTemplate.update(query);
            System.out.println("query executed");
            return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteAsset(int id) {
        String query="delete from asset where asset_id="+id;
        try{

            int count= jdbcTemplate.update(query);
            return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }
}
