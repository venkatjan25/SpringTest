package com.example.springtest.employee.daoimpl;

import com.example.springtest.employee.dao.EmployeeDAO;
import com.example.springtest.employee.dto.Employee;
import com.example.springtest.employee.mapper.EmployeeRowMapper;
import com.example.springtest.employee.vo.EmployeeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Employee> getAllEmployees() {
        String query= "select * from employee e , organization o where e.org_id=o.org_id ";
        try{
            return jdbcTemplate.query(query,new EmployeeRowMapper());
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return null;
    }

    @Override
    public Employee getEmployeeById(int emp_id) {
        String query= "select * from employee e , organization o where e.emp_id=:emp_id and o.org_id=e.org_id";
        query =query.replaceAll(":emp_id",String.valueOf(emp_id));
        Employee employee = new Employee();
        try{
           SqlRowSet rowSet=  jdbcTemplate.queryForRowSet(query);
            while (rowSet.next()) {
                employee.setEmpId(rowSet.getInt("emp_id"));
                employee.setEmpName(rowSet.getString("emp_name"));
                employee.setOrgName(rowSet.getString("org_name"));
                employee.setDepartment(rowSet.getString("emp_dept"));
            }
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return employee;
    }

    @Override
    public boolean saveEmployee(EmployeeVO employeeVO) {
        String query="insert into employee (org_id,emp_name,emp_dept) values(?,?,?)";
        try{
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(query, new String[] { "emp_id" });
                ps.setInt(1, employeeVO.getOrgId());
                ps.setString(2, employeeVO.getEmpName());
                ps.setString(3, employeeVO.getEmpDepartment());
                return ps;
            }, keyHolder);
            return keyHolder.getKey().longValue()>0;

        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateEmployee(int id, EmployeeVO employeeVO) {

        String query="update employee set org_id=orgId,emp_name='empName',emp_dept='empDept' where emp_id="+id;
        try{
            query= query.replaceAll("orgId",String.valueOf(employeeVO.getOrgId()));
            query=query.replaceAll("empName",employeeVO.getEmpName());
           query=query.replaceAll("empDept",employeeVO.getEmpDepartment());
            int count= jdbcTemplate.update(query);
            System.out.println("query executed");
            return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteEmployee(int id) {
        String query="delete from employee where emp_id="+id;
        try{

            int count= jdbcTemplate.update(query);
            System.out.println("query executed");
            return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }
}
