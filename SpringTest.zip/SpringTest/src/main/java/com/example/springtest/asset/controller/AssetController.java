package com.example.springtest.asset.controller;

import com.example.springtest.asset.dto.Asset;
import com.example.springtest.asset.service.AssetService;
import com.example.springtest.asset.vo.AssetVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("assets")
public class AssetController {

    @Autowired
    private AssetService assetService;

    @GetMapping("getAll")
    public ResponseEntity<List<Asset>> getAll(){
        List<Asset> list= assetService.getAllAssets();
        if(list.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(list,HttpStatus.OK);
    }

    @GetMapping( "getById/{id}")
    public  ResponseEntity<Asset>  getAssetById(@PathVariable("id") int id) throws SQLException {
        Asset asset=  assetService.getAssetById(id);
        if(asset!=null){
            return new ResponseEntity<>(asset,HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("newAsset")
    public ResponseEntity<String> saveAsset(@RequestBody AssetVO assetVO){
        boolean result = assetService.saveAsset(assetVO);
        if(result){
            return new ResponseEntity<>("Asset inserted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

    @PutMapping("updateAsset/{id}")
    public ResponseEntity<String> updateAsset(@PathVariable("id") int id, @RequestBody AssetVO assetVO){
        boolean result = assetService.updateAsset(id, assetVO);
        if(result){
            return new ResponseEntity<>("Asset updated successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }
    @DeleteMapping("deleteAsset/{id}")
    public ResponseEntity<String> deleteAsset(@PathVariable("id") int id){
        boolean result = assetService.deleteAsset(id);
        if(result){
            return new ResponseEntity<>("Asset deleted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

}
