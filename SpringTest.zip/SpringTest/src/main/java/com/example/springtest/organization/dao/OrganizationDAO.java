package com.example.springtest.organization.dao;

import com.example.springtest.organization.dto.Organization;
import com.example.springtest.organization.vo.OrganizationVO;

import java.util.List;

public interface OrganizationDAO {
    List<Organization> getAllOrganizations();

    Organization getOrganizationById(int id);

    boolean saveOrganization(OrganizationVO organizationVO);

    boolean updateOrganization(int orgId, OrganizationVO organizationVO);

    boolean deleteOrganization(int orgId);
}
