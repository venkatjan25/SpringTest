package com.example.springtest.organization.daoimpl;

import com.example.springtest.mapper.OrganizationRowMapper;
import com.example.springtest.organization.dao.OrganizationDAO;
import com.example.springtest.organization.dto.Organization;
import com.example.springtest.organization.vo.OrganizationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;

@Repository
public class OrganizationDAOImpl implements OrganizationDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Organization> getAllOrganizations(){
        try{
            return jdbcTemplate.query("select * from organization",new OrganizationRowMapper());
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return null;
    }

    public Organization getOrganizationById(int id){
        Organization organization = new Organization();
        try{
            String query="select * from organization where org_id="+id;
            SqlRowSet rowSet=  jdbcTemplate.queryForRowSet(query);
            while (rowSet.next()){
                organization.setOrgId(rowSet.getInt("org_id"));
                organization.setOrgName(rowSet.getString("org_name"));
                organization.setOrgCity(rowSet.getString("org_city"));
            }
        }catch (Exception e){
            System.out.println("Exception is occured while retreiving the organizations");
        }
        return organization;
    }

    @Override
    public boolean saveOrganization(OrganizationVO organizationVO) {
        String query="insert into organization (org_name,org_city) values(?,?)";
        try{
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(query, new String[] { "org_id" });
                ps.setString(1, organizationVO.getOrgname());
                ps.setString(2, organizationVO.getOrgcity());
                return ps;
            }, keyHolder);
            return keyHolder.getKey().longValue()>0;

        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }
    @Override
    public boolean updateOrganization(int orgId, OrganizationVO organizationVO) {
        String query="update organization set org_name=':orgName',org_city=':orgCity' where org_id="+orgId;
        try{
            query= query.replaceAll("orgName",organizationVO.getOrgname());
            query=query.replaceAll("orgCity",organizationVO.getOrgcity());
           int count= jdbcTemplate.update(query);
           System.out.println("query executed");
           return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteOrganization(int orgId) {
        String query="delete from organization where org_id="+orgId;
        try{

            int count= jdbcTemplate.update(query);
            System.out.println("query executed");
            return count>0;
        }catch (Exception e){
            System.out.println("Exception occured while saving the record"+e.getMessage());
        }
        return false;
    }




}
