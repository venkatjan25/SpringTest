package com.example.springtest.employee.mapper;

import com.example.springtest.employee.dto.Employee;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeRowMapper implements RowMapper<Employee> {



    @Override
    public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
        Employee employee =new Employee();
        employee.setEmpId(rs.getInt("emp_id"));
        employee.setOrgName(rs.getString("org_name"));
        employee.setEmpName(rs.getString("emp_name"));
        employee.setDepartment(rs.getString("emp_dept"));
        return employee;
    }
}
