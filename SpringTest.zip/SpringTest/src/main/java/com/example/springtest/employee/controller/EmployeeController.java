package com.example.springtest.employee.controller;

import com.example.springtest.employee.dto.Employee;
import com.example.springtest.employee.service.EmployeeService;
import com.example.springtest.employee.vo.EmployeeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("getAll")
    public ResponseEntity<List<Employee>> getAll(){
        List<Employee> list= employeeService.getAllEmployees();
        if(list.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(list,HttpStatus.OK);
    }

    @GetMapping( "getById/{id}")
    public  ResponseEntity<Employee>  getEmployeeById(@PathVariable("id") int id) throws SQLException {
        Employee employee=  employeeService.getEmployeeById(id);
        if(employee!=null){
            return new ResponseEntity<>(employee,HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("newEmployee")
    public ResponseEntity<String> saveEmployee(@RequestBody EmployeeVO employeeVO){
        boolean result = employeeService.saveEmployee(employeeVO);
        if(result){
            return new ResponseEntity<>("Employee inserted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

    @PutMapping("updateEmployee/{id}")
    public ResponseEntity<String> updateEmployee(@PathVariable("id") int id, @RequestBody EmployeeVO employeeVO){
        boolean result = employeeService.updateEmployee(id, employeeVO);
        if(result){
            return new ResponseEntity<>("Employee updated successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }
    @DeleteMapping("deleteEmployee/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") int id){
        boolean result = employeeService.deleteEmployee(id);
        if(result){
            return new ResponseEntity<>("Employee deleted successfully",HttpStatus.OK);
        }
        return  new ResponseEntity<>("failed",HttpStatus.OK);

    }

}
