package com.example.springtest.employee.service;

import com.example.springtest.employee.dao.EmployeeDAO;
import com.example.springtest.employee.dto.Employee;
import com.example.springtest.employee.vo.EmployeeVO;
import com.example.springtest.organization.dto.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeDAO employeeDAO;
    public List<Employee> getAllEmployees() {
        return employeeDAO.getAllEmployees();
    }

    public Employee getEmployeeById(int id) {
        return employeeDAO.getEmployeeById(id);
    }

    public boolean saveEmployee(EmployeeVO employeeVO) {
        return employeeDAO.saveEmployee(employeeVO);
    }

    public boolean updateEmployee(int id, EmployeeVO employeeVO) {
        return employeeDAO.updateEmployee(id, employeeVO);
    }

    public boolean deleteEmployee(int id) {
        return employeeDAO.deleteEmployee(id);
    }
}
