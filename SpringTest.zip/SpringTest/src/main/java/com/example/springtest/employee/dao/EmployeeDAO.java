package com.example.springtest.employee.dao;

import com.example.springtest.employee.dto.Employee;
import com.example.springtest.employee.vo.EmployeeVO;

import java.util.List;

public interface EmployeeDAO {
    List<Employee> getAllEmployees();
    Employee getEmployeeById(int id);

    boolean saveEmployee(EmployeeVO employeeVO);

    boolean updateEmployee(int id, EmployeeVO employeeVO);

    boolean deleteEmployee(int id);
}
