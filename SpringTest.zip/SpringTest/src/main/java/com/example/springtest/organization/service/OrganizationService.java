package com.example.springtest.organization.service;

import com.example.springtest.organization.dao.OrganizationDAO;
import com.example.springtest.organization.dto.Organization;
import com.example.springtest.organization.vo.OrganizationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizationService {
    @Autowired
    private OrganizationDAO organizationDAO;
    public List<Organization> getAllOrganizations() {
        return organizationDAO.getAllOrganizations();
    }
    public Organization getOrganizationById(int id) {
        return organizationDAO.getOrganizationById(id);
    }

    public boolean saveOrganization(OrganizationVO organizationVO) {
      return  organizationDAO.saveOrganization(organizationVO);
    }

    public boolean updateOrganization(int orgId, OrganizationVO organizationVO) {
        return  organizationDAO.updateOrganization(orgId,organizationVO);
    }

    public boolean deleteOrganization(int orgId) {
        return  organizationDAO.deleteOrganization(orgId);
    }
}
