DROP TABLE IF EXISTS organization;
CREATE TABLE organization (
                      org_id int auto_increment  primary key,
                      org_name VARCHAR(50) not null,
                      org_city varchar(50) not null
);

DROP TABLE IF EXISTS employee;
CREATE TABLE employee (
                          emp_id int auto_increment  primary key,
                          org_id int not null,
                          emp_name varchar(50) not null,
                          emp_dept varchar(50) not null
);

DROP TABLE IF EXISTS asset;
CREATE TABLE asset (
                          asset_id int auto_increment  primary key,
                          emp_id int not null,
                          asset_name varchar(50) not null
);