INSERT INTO organization VALUES (101, 'Seimens', 'Hyderabad');
INSERT INTO organization VALUES (102, 'Seimens', 'Chennai');
INSERT INTO organization VALUES (103, 'Seimens', 'Banglore');

INSERT INTO employee VALUES (1001, 101, 'Venkat','finance');
INSERT INTO employee VALUES (1002, 103, 'Bharat','hr');
INSERT INTO employee VALUES (1003, 101, 'Sai','hr');

INSERT INTO asset VALUES (10001, 1001, 'Mouse');
INSERT INTO asset VALUES (10002, 1002, 'Keyboard');
INSERT INTO asset VALUES (10003, 1003, 'Monitor');
